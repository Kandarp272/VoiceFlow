"""VoiceFlow — offline-first AI voice dictation for any app."""
__version__ = "1.0.0"
