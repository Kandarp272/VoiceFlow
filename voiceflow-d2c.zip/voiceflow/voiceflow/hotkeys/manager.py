"""
HotkeyManager — registers global hotkeys using pynput.
Hotkeys work system-wide regardless of which app has focus.

Supported hotkeys (configurable in config.yaml):
  toggle          — start/stop dictation
  push_to_talk    — hold to dictate (TODO: requires press+release tracking)
  switch_backend  — cycle through ASR backends
  quit            — exit VoiceFlow

Key notation (pynput GlobalHotKeys format):
  <ctrl>+<alt>+q
  <alt>+<space>
  <shift>+a
"""

from __future__ import annotations

import logging
import threading
from typing import Callable, TYPE_CHECKING

from pynput import keyboard  # type: ignore

if TYPE_CHECKING:
    from voiceflow.config.settings import Settings

log = logging.getLogger(__name__)

Callback = Callable[[], None]


class HotkeyManager:
    """
    Wraps pynput.keyboard.GlobalHotKeys.
    Runs in its own daemon thread so it doesn't block the audio or UI threads.
    """

    def __init__(
        self,
        settings: "Settings",
        callbacks: dict[str, Callback],
    ) -> None:
        self.cfg = settings.hotkeys
        self.callbacks = callbacks
        self._listener: keyboard.GlobalHotKeys | None = None
        self._thread: threading.Thread | None = None

        # For push-to-talk we need separate press/release tracking
        self._ptt_active = False
        self._ptt_callback = callbacks.get("push_to_talk")

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def start(self) -> None:
        hotkey_map = self._build_hotkey_map()
        log.info(
            "Registering hotkeys: %s",
            list(hotkey_map.keys()),
        )
        self._listener = keyboard.GlobalHotKeys(hotkey_map)
        self._listener.daemon = True
        self._listener.start()
        log.info("Hotkey listener running")

    def stop(self) -> None:
        if self._listener is not None:
            self._listener.stop()
            self._listener = None

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _build_hotkey_map(self) -> dict[str, Callable]:
        bindings: dict[str, Callable] = {}

        def _safe(name: str, fn: Callback) -> Callback:
            """Wrap callback to catch and log exceptions."""
            def wrapper():
                try:
                    fn()
                except Exception as exc:
                    log.error("Hotkey callback %r raised: %s", name, exc, exc_info=True)
            return wrapper

        if cb := self.callbacks.get("toggle"):
            bindings[self.cfg.toggle] = _safe("toggle", cb)

        if cb := self.callbacks.get("switch_backend"):
            bindings[self.cfg.switch_backend] = _safe("switch_backend", cb)

        if cb := self.callbacks.get("quit"):
            bindings[self.cfg.quit] = _safe("quit", cb)

        # Push-to-talk: pynput GlobalHotKeys fires on press.
        # We handle release separately via a low-level listener.
        if cb := self.callbacks.get("push_to_talk"):
            bindings[self.cfg.push_to_talk] = _safe(
                "push_to_talk_press", lambda: self._on_ptt_press()
            )
            self._start_ptt_release_listener()

        return bindings

    def _on_ptt_press(self) -> None:
        if not self._ptt_active:
            self._ptt_active = True
            if fn := self.callbacks.get("push_to_talk"):
                fn.__call__() if callable(fn) else None  # type: ignore
            # Call with pressed=True
            self._dispatch_ptt(True)

    def _on_ptt_release(self) -> None:
        if self._ptt_active:
            self._ptt_active = False
            self._dispatch_ptt(False)

    def _dispatch_ptt(self, pressed: bool) -> None:
        if fn := self.callbacks.get("push_to_talk"):
            try:
                # If callback accepts a bool arg, pass it
                import inspect
                sig = inspect.signature(fn)
                if len(sig.parameters) > 0:
                    fn(pressed)  # type: ignore
                else:
                    fn()
            except Exception as exc:
                log.error("PTT callback error: %s", exc)

    def _start_ptt_release_listener(self) -> None:
        """
        Spin up a separate pynput listener to detect key releases
        for push-to-talk support.
        """
        ptt_combo = self._parse_combo(self.cfg.push_to_talk)

        def on_release(key):
            try:
                key_str = key.char if hasattr(key, "char") else str(key)
            except Exception:
                key_str = str(key)
            # Naive check — good enough for modifier+key combos
            if self._ptt_active:
                self._on_ptt_release()

        release_listener = keyboard.Listener(on_release=on_release)
        release_listener.daemon = True
        release_listener.start()

    @staticmethod
    def _parse_combo(hotkey_str: str) -> list[str]:
        """Split '<ctrl>+<alt>+q' into ['ctrl', 'alt', 'q']."""
        parts = hotkey_str.split("+")
        return [p.strip("<>") for p in parts]
